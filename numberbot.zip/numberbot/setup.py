from setuptools import find_packages, setup

package_name = 'numberbot'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/numberbot_launch.xml']),
        ('share/' + package_name + '/launch', ['launch/numberbot_launch.py']),
        ('share/' + package_name + '/urdf', ['urdf/numberbot.urdf']),
        ('share/' + package_name + '/config', ['config/controllers.yaml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='nossam',
    maintainer_email='nossam@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
        'number_writer=numberbot.number_writer:main',
        ],
    },
)
