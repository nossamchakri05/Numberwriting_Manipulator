from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess

from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    package_dir = get_package_share_directory('numberbot')
    urdf_path = os.path.join(package_dir, 'urdf', 'numberbot.urdf')
    config_path = os.path.join(package_dir, 'config', 'controllers.yaml')

    return LaunchDescription([
        # Start Gazebo with factory plugin
        ExecuteProcess(
            cmd=['gazebo', '--verbose', '-s', 'libgazebo_ros_factory.so'],
            output='screen'
        ),

        # Robot State Publisher
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{'robot_description': open(urdf_path).read()}]
        ),

        # Spawn robot in Gazebo
        Node(
            package='gazebo_ros',
            executable='spawn_entity.py',
            name='spawn_numberbot',
            arguments=['-entity', 'numberbot', '-file', urdf_path],
            output='screen'
        ),

        # Load joint_state_broadcaster
        Node(
            package='controller_manager',
            executable='spawner',
            name='spawner_joint_state_broadcaster',
            arguments=['joint_state_broadcaster', '--controller-manager-timeout', '50'],
            output='screen'
        ),

        # Load arm_controller
        Node(
            package='controller_manager',
            executable='spawner',
            name='spawner_arm_controller',
            arguments=['arm_controller', '--controller-manager-timeout', '50'],
            output='screen'
        )
    ])

