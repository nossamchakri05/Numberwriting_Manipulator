import rclpy
from rclpy.node import Node
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from builtin_interfaces.msg import Duration

class NumberWriter(Node):
    def __init__(self):
        super().__init__('number_writer')
        self.publisher = self.create_publisher(
            JointTrajectory, '/arm_controller/joint_trajectory', 10
        )
        self.timer = self.create_timer(3.0, self.send_trajectory)
        self.index = 0
        self.sequence = []

        self.joint_names = ['hip', 'shoulder', 'elbow', 'wrist']

        # Digit joint positions: only 1, 3, 4, 5, 9, 0
        self.digits = {
            '1': [
                [-0.2, 0.7, -1.3, 0.0],
                [0.0, 0.7, -1.5, 0.0],
                [0.0, 0.7, -0.1, 0.0],
                [-0.3, 0.7, -0.1, 0.0],
                [0.3, 0.7, -0.1, 0.0],
            ],
            '3': [
                [-0.6, 0.7, -1.5, 0.0],
                [0.0, 0.7, -1.5, 0.0],
                [0.0, 0.7, -1.0, 0.0],
                [-0.6, 0.7, -1.0, 0.0],
                [0.0, 0.7, -1.0, 0.0],
                [0.0, 0.7, -0.5, 0.0],
                [-0.6, 0.7, -0.5, 0.0]
            ],
            '4': [
                [-0.6, 0.7, -1.5, 0.0],
                [-0.6, 0.7, -0.7, 0.0],
                [0.0, 0.7, -0.7, 0.0],
                [0.0, 0.7, -1.5, 0.0],
                [0.0, 0.7, -0.2, 0.0],
            ],
            '5': [
                [-0.0, 0.7, -1.5, 0.0],
                [-0.6, 0.7, -1.5, 0.0],
                [-0.6, 0.7, -0.80, 0.0],
                [0.0, 0.7, -0.80, 0.0],
                [-0.0, 0.7, -0.1, 0.0],
                [-0.6, 0.7, -0.1, 0.0],
            ],
            '9': [
                [0.0, 0.7, -0.85, 0.0],
                [-0.6, 0.7, -0.85, 0.0],
                [-0.6, 0.7, -1.5, 0.0],
                [0.0, 0.7, -1.5, 0.0],
                [0.0, 0.7, -0.1, 0.0],
                [-0.6, 0.7, -0.1, 0.0],
            ],
            '0': [
                [-0.3, 0.7, -0.1, 0.0],
                [-0.6, 0.7, -0.6, 0.0],
                [-0.6, 0.7, -1.1, 0.0],
                [-0.3, 0.7, -1.5, 0.0],
                [0.3, 0.7, -1.5, 0.0],
                [0.6, 0.7, -1.1, 0.0],
                [0.6, 0.7, -0.6, 0.0],
                [0.3, 0.7, -0.1, 0.0],
                [-0.3, 0.7, -0.1, 0.0],
            ]
        }

        self.prompt_user()

    def prompt_user(self):
        print("\nEnter numbers to draw (space-separated). Valid digits: 1, 3, 4, 5, 9, 0")
        user_input = input("Input: ")
        digits_list = user_input.strip().split()
        valid_digits = []

        for digit in digits_list:
            if digit in self.digits:
                print(f"Preparing to draw '{digit}'")
                valid_digits.append(digit)
            else:
                print(f"Invalid digit '{digit}' skipped.")

        if valid_digits:
            self.sequence = [pose for digit in valid_digits for pose in self.digits[digit]]
            self.index = 0
            print(f"Drawing sequence: {' '.join(valid_digits)}")
        else:
            print("No valid digits entered. Please try again.")
            self.prompt_user()

    def send_trajectory(self):
        if self.index >= len(self.sequence):
            self.get_logger().info("Finished drawing all digits.")
            self.timer.cancel()
            self.prompt_user()
            self.index = 0
            self.timer.reset()
            return

        position = self.sequence[self.index]
        traj = JointTrajectory()
        traj.joint_names = self.joint_names

        point = JointTrajectoryPoint()
        point.positions = position
        point.time_from_start = Duration(sec=2)
        traj.points.append(point)

        self.publisher.publish(traj)

        print(f"\n[Step {self.index + 1}/{len(self.sequence)}] Sending joint command:")
        for name, pos in zip(self.joint_names, position):
            joint_action = f"{name.capitalize()} moved to {pos:.3f} radians"
            print(f"  {joint_action}")

        self.index += 1


def main(args=None):
    rclpy.init(args=args)
    node = NumberWriter()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

